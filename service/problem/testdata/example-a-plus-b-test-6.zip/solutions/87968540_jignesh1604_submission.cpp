/*
    Author  :   jignesh1604
    College :   SVNIT
    -------------------------------"Whatever's good for your soul, do that"-----------------------------
    1 contest + 2 upsolve + 1 new topic + 5 problems = 1900+ of cf in 3 months
*/

#include<bits/stdc++.h>
using namespace std;

void solve() {
    long long int a , b;
    cin >> a >> b;
    cout << a + b << "\n";
}

int main() {
    long long int tc = 1;
    // cin >> tc;
    while(tc-- > 0) {
        solve();
    }
}